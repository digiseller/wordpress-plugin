=== Digiseller ===
Contributors: digiseller
Tags: digiseller, shop, commerce, sell
Requires at least: 3.0.1
Tested up to: 4.9.5
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy integration of http://digiseller.ru into your website.

== Description ==

Easy integration of http://digiseller.ru into your website.
[Installation documentation with screenshots.](https://docs.google.com/document/d/1oaKI6tHKOYEwWZ9k-vgBC3sGYskKkuZ74amQ-RzhQEA/)

== Installation ==

1. Upload `digiseller` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1.
 * Configure from 'Settins->Digiseller' menu in WordPress
 * Use short code `[ds id="xxx" op="logo,search,cart,purchases,lang,cath,menu,widen"]` in your content
